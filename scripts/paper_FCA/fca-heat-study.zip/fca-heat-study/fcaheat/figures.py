"""Figure library. Every function writes results/figures/<name>.html (+ .svg with kaleido)."""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots

from .config import CFG, FIG_DIR, res_step
from .data import Inputs
from .fca import build_grid_limit
from .model import slice_horizon

C = dict(base="#9ecae1", hp="#08519c", eb="#e6550d", gas="#7f7f7f",
         tes_ch="#2ca02c", tes_dis="#98df8a", bes_ch="#7d3ac1", bes_dis="#c5b0d5",
         grid="#111111", limit="#c00000", price="#f6a600", soc="#7d3ac1",
         restricted="#c00000", flex="#2ca02c")
SCEN_COLOR = {"S0_BASE": "#7f7f7f", "S1_NOSTOR": "#c00000", "S2_TES": "#2ca02c",
              "S3_BES": "#7d3ac1", "S4_TES_BES": "#08519c"}
FCA_COLOR = {"FCA_FIRM": "#111111", "FCA_UPGRADE": "#9ecae1", "FCA_STATIC": "#7f7f7f",
             "FCA_WINDOW": "#08519c", "FCA_WINDOW_WIDE": "#6baed6", "FCA_DYNAMIC": "#e6550d",
             "FCA_TDTR": "#2ca02c"}

pio.templates.default = "plotly_white"
_t = pio.templates["plotly_white"]
_t.layout.font = dict(family="Arial", size=13, color="#222222")
_t.layout.xaxis.update(showline=True, linewidth=1, linecolor="#444", mirror=True,
                       ticks="outside", gridcolor="#e8e8e8")
_t.layout.yaxis.update(showline=True, linewidth=1, linecolor="#444", mirror=True,
                       ticks="outside", gridcolor="#e8e8e8")
PLOT_CONFIG = {"displaylogo": False, "toImageButtonOptions": {"format": "svg", "scale": 2}}
IN_NOTEBOOK = "ipykernel" in sys.modules


def show(fig, name: str, w: int = 1100, h: int = 520):
    fig.update_layout(width=w, height=h, margin=dict(l=70, r=30, t=60, b=60),
                      legend=dict(orientation="h", y=-0.18, x=0), title_x=0.0)
    fig.write_html(FIG_DIR / f"{name}.html", include_plotlyjs="cdn")
    try:
        fig.write_image(FIG_DIR / f"{name}.svg")
    except Exception:
        pass
    if IN_NOTEBOOK:
        fig.show(config=PLOT_CONFIG)
    return fig


def _blocks(mask, index):
    """Contiguous True runs of `mask` as (start, end) timestamps — for shading."""
    out, run = [], None
    for i, v in enumerate(mask):
        if v and run is None:
            run = index[i]
        elif not v and run is not None:
            out.append((run, index[i])); run = None
    if run is not None:
        out.append((run, index[-1]))
    return out


def fig_demand_overview(inp: Inputs, year=None):
    year = year or CFG["years"][0]
    sites = list(inp.sites["site_id"])
    names = dict(zip(inp.sites["site_id"], inp.sites["site_name"]))
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[0.5, 0.5],
                        vertical_spacing=0.10,
                        subplot_titles=("Electricity demand — monthly mean [MW]",
                                        "Heat demand — monthly mean [MW<sub>th</sub>]"))
    pal = ["#08519c", "#e6550d", "#2ca02c", "#7d3ac1", "#c00000"]
    for i, s in enumerate(sites):
        e = inp.el.loc[inp.el.index.year == year, s].resample("ME").mean()
        q = inp.heat.loc[inp.heat.index.year == year, s].resample("ME").mean()
        fig.add_trace(go.Scatter(x=e.index, y=e, name=names[s], line=dict(color=pal[i], width=2),
                                 legendgroup=s), row=1, col=1)
        fig.add_trace(go.Scatter(x=q.index, y=q, name=names[s], line=dict(color=pal[i], width=2),
                                 legendgroup=s, showlegend=False), row=2, col=1)
    fig.update_layout(title=f"Site demand profiles ({year})")
    return show(fig, "F1_demand_overview", h=680)


def fig_duration_curves(inp: Inputs, year=None):
    year = year or CFG["years"][0]
    names = dict(zip(inp.sites["site_id"], inp.sites["site_name"]))
    pal = ["#08519c", "#e6550d", "#2ca02c", "#7d3ac1", "#c00000"]
    fig = make_subplots(rows=1, cols=2, subplot_titles=("Electricity", "Heat"))
    for i, s in enumerate(inp.sites["site_id"]):
        for c, (src, col) in enumerate([(inp.el, 1), (inp.heat, 2)]):
            y = np.sort(src.loc[src.index.year == year, s].to_numpy())[::-1]
            x = np.arange(1, len(y) + 1) * 0.25
            fig.add_trace(go.Scatter(x=x, y=y, name=names[s], line=dict(color=pal[i], width=2),
                                     legendgroup=s, showlegend=(col == 1)), row=1, col=col)
    fig.update_xaxes(title_text="hours per year [h]")
    fig.update_yaxes(title_text="power [MW]", row=1, col=1)
    fig.update_layout(title=f"Load duration curves ({year})")
    return show(fig, "F2_duration_curves", h=460)


def fig_limit_profile(inp: Inputs, site: str, fcas=None, days=7, start=None):
    """The connection limit as the model sees it — the paper's explanatory figure."""
    fcas = fcas or CFG["fcas"]
    P0 = float(inp.sites.set_index("site_id").loc[site, "P_grid_exist_MW"])
    df, dt = slice_horizon(inp, site, tuple(CFG["years"]), CFG["resolution"])
    start = start or df.index[0] + pd.Timedelta(days=14)
    idx = df.loc[start:start + pd.Timedelta(days=days)].index
    fig = go.Figure()
    for fc in fcas:
        lim, free, restr, _ = build_grid_limit(inp, fc, idx, P0,
                                               df.loc[idx, "price"].to_numpy(), dt)
        if free:
            continue
        fig.add_trace(go.Scatter(x=idx, y=lim, name=fc, line_shape="hv",
                                 line=dict(color=FCA_COLOR.get(fc), width=2)))
    fig.add_trace(go.Scatter(x=idx, y=df.loc[idx, "el"], name="existing electricity demand",
                             line=dict(color=C["base"], width=1.5), fill="tozeroy"))
    fig.update_layout(title=f"Connection limit P<sub>limit</sub>(t) by regime — {site}",
                      yaxis_title="power [MW]")
    return show(fig, f"F3_limit_profile_{site}")


def fig_feasibility_matrix(kpi: pd.DataFrame):
    """Which (configuration, regime) combinations can supply 100 % of the heat demand?"""
    k = kpi[kpi["scenario"] != "S0_BASE"]
    piv = k.pivot_table(index=["scenario"], columns="fca",
                        values="unserved_share_pct", aggfunc="mean")
    fig = go.Figure(go.Heatmap(z=piv.values, x=list(piv.columns), y=list(piv.index),
                               colorscale="Reds", zmin=0,
                               colorbar=dict(title="unserved<br>heat [%]"),
                               text=np.round(piv.values, 2), texttemplate="%{text}"))
    fig.update_layout(title="Unserved heat by storage configuration and connection regime "
                            "(mean over sites)")
    return show(fig, "F4_feasibility_matrix", h=420)


def fig_storage_vs_regime(kpi: pd.DataFrame):
    k = kpi[kpi["scenario"].isin(["S2_TES", "S3_BES", "S4_TES_BES"])]
    fig = make_subplots(rows=1, cols=2, subplot_titles=("TES [MWh<sub>th</sub>]",
                                                        "BES [MWh<sub>el</sub>]"))
    for fc in k["fca"].unique():
        d = k[k["fca"] == fc]
        g = d.groupby("scenario")[["Etes_MWh", "Ebes_MWh"]].mean()
        fig.add_bar(x=g.index, y=g["Etes_MWh"], name=fc, marker_color=FCA_COLOR.get(fc),
                    legendgroup=fc, row=1, col=1)
        fig.add_bar(x=g.index, y=g["Ebes_MWh"], name=fc, marker_color=FCA_COLOR.get(fc),
                    legendgroup=fc, showlegend=False, row=1, col=2)
    fig.update_layout(barmode="group", title="Storage size required by connection regime "
                                             "(mean over sites)")
    return show(fig, "F5_storage_vs_regime", h=460)


def fig_dispatch(ts_store, site: str, scenario: str, fca: str = "FCA_WINDOW",
                 start=None, days=7):
    ts = ts_store[(site, scenario, fca)]
    start = start or ts.index[0] + pd.Timedelta(days=14)
    w = ts.loc[start:start + pd.Timedelta(days=days)]
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, row_heights=[0.40, 0.34, 0.26],
                        vertical_spacing=0.06,
                        subplot_titles=("Electricity side [MW]", "Heat side [MW<sub>th</sub>]",
                                        "Storage level / price"))
    # electricity
    for col, nm, cc in [("el_base", "existing load", C["base"]), ("p_hp", "heat pump", C["hp"]),
                        ("p_eb", "electrode boiler", C["eb"]), ("bes_ch", "BES charge", C["bes_ch"])]:
        fig.add_trace(go.Scatter(x=w.index, y=w[col], name=nm, line_shape="hv", stackgroup="e",
                                 line=dict(width=0, color=cc)), row=1, col=1)
    fig.add_trace(go.Scatter(x=w.index, y=w["grid"], name="grid draw",
                             line=dict(color=C["grid"], width=2), line_shape="hv"), row=1, col=1)
    fig.add_trace(go.Scatter(x=w.index, y=w["P_limit"], name="P<sub>limit</sub>(t)",
                             line=dict(color=C["limit"], width=2, dash="dash"),
                             line_shape="hv"), row=1, col=1)
    for a, b in _blocks(w["restricted"].to_numpy(), w.index):
        fig.add_vrect(x0=a, x1=b, fillcolor=C["restricted"], opacity=0.07, line_width=0,
                      layer="below", row=1, col=1)
    # heat
    for col, nm, cc in [("q_hp", "HP heat", C["hp"]), ("q_eb", "EB heat", C["eb"]),
                        ("tes_dis", "TES discharge", C["tes_dis"])]:
        fig.add_trace(go.Scatter(x=w.index, y=w[col], name=nm, line_shape="hv", stackgroup="h",
                                 line=dict(width=0, color=cc)), row=2, col=1)
    fig.add_trace(go.Scatter(x=w.index, y=w["heat_dem"], name="heat demand",
                             line=dict(color="#111", width=2, dash="dot"), line_shape="hv"),
                  row=2, col=1)
    # storage + price
    fig.add_trace(go.Scatter(x=w.index, y=w["tes_soc"], name="TES SOC [MWh]",
                             line=dict(color=C["tes_ch"], width=2), fill="tozeroy"), row=3, col=1)
    fig.add_trace(go.Scatter(x=w.index, y=w["bes_soc"], name="BES SOC [MWh]",
                             line=dict(color=C["soc"], width=2)), row=3, col=1)
    fig.add_trace(go.Scatter(x=w.index, y=w["price"] / 10, name="price [10 EUR/MWh]",
                             line=dict(color=C["price"], width=1.2, dash="dot")), row=3, col=1)
    fig.update_layout(title=f"Dispatch — {site} · {scenario} · {fca} · "
                            f"{start:%d %b %Y} + {days} d")
    return show(fig, f"F6_dispatch_{site}_{scenario}_{fca}", h=760)


def fig_grid_duration(ts_store, site: str, scenario="S4_TES_BES", fcas=None, inp=None):
    fcas = fcas or CFG["fcas"]
    fig = go.Figure()
    for fc in fcas:
        if (site, scenario, fc) not in ts_store:
            continue
        y = np.sort(ts_store[(site, scenario, fc)]["grid"].to_numpy())[::-1]
        x = np.arange(1, len(y) + 1) * res_step()
        fig.add_trace(go.Scatter(x=x, y=y, name=fc,
                                 line=dict(color=FCA_COLOR.get(fc), width=2)))
    if inp is not None:
        fig.add_hline(y=float(inp.sites.set_index("site_id").loc[site, "P_grid_exist_MW"]),
                      line=dict(color=C["limit"], dash="dash"),
                      annotation_text="P<sub>grid,exist</sub>")
    fig.update_layout(title=f"Grid draw duration curve — {site} · {scenario}",
                      xaxis_title="hours [h]", yaxis_title="grid draw [MW]")
    return show(fig, f"F7_grid_duration_{site}_{scenario}")


def fig_kpi_comparison(kpi: pd.DataFrame, scenario="S4_TES_BES"):
    metrics = [("Etes_MWh", "TES size [MWh]"), ("LCOH_EUR_MWh", "LCOH [EUR/MWh<sub>th</sub>]"),
               ("peak_grid_MW", "peak grid draw [MW]"),
               ("unserved_share_pct", "unserved heat [%]")]
    fig = make_subplots(rows=2, cols=2, subplot_titles=[m[1] for m in metrics],
                        vertical_spacing=0.16)
    for i, (col, _) in enumerate(metrics):
        r, c = divmod(i, 2)
        for fc in kpi["fca"].dropna().unique():
            d = kpi[(kpi["fca"] == fc) & (kpi["scenario"] == scenario)]
            fig.add_bar(x=d["site"], y=d[col], name=fc, marker_color=FCA_COLOR.get(fc),
                        legendgroup=fc, showlegend=(i == 0), row=r + 1, col=c + 1)
    fig.update_layout(barmode="group",
                      title=f"Connection regime comparison across sites — {scenario}")
    return show(fig, "F8_kpi_comparison", h=760)


def fig_cost_stack(kpi: pd.DataFrame):
    k = kpi[(kpi["scenario"] != "S0_BASE") & (kpi["fca"] == "FCA_WINDOW")].copy()
    k["x"] = k["site"] + "<br>" + k["scenario"]
    fig = go.Figure()
    for col, nm, cc in [("cost_capex_EUR", "annualised CAPEX+OPEX", C["hp"]),
                        ("cost_energy_EUR", "energy", C["eb"]),
                        ("cost_capacity_EUR", "grid capacity charge", C["base"])]:
        fig.add_bar(x=k["x"], y=k[col] / 1e6, name=nm, marker_color=cc)
    fig.update_layout(barmode="stack", title="Annual cost structure",
                      yaxis_title="cost [MEUR/a]")
    return show(fig, "F9_cost_structure", h=560)


def fig_tornado(sens: pd.DataFrame, kpi_col="Etes_MWh", label="TES size [MWh]"):
    rows = []
    for pid, g in sens.groupby("param_id"):
        g = g.sort_values("value")
        base = g.iloc[(g["value"] - g["base"]).abs().argsort()].iloc[0][kpi_col]
        rows.append(dict(param=pid, low=g.iloc[0][kpi_col] - base,
                         high=g.iloc[-1][kpi_col] - base, base=base))
    t = pd.DataFrame(rows)
    t["span"] = (t["high"] - t["low"]).abs()
    t = t.sort_values("span")
    fig = go.Figure()
    fig.add_bar(y=t["param"], x=t["low"], orientation="h", name="low", marker_color="#9ecae1")
    fig.add_bar(y=t["param"], x=t["high"], orientation="h", name="high", marker_color="#c00000")
    fig.update_layout(barmode="overlay", title=f"Sensitivity of {label}",
                      xaxis_title=f"change in {label}")
    return show(fig, f"F9_tornado_{kpi_col}", h=520)


def fig_notice_value(mpc: pd.DataFrame):
    """What a longer notification interval is worth, at identical hardware."""
    fig = go.Figure()
    for nh, g in mpc.groupby("notice_h"):
        d = g.groupby("site")["foresight_gap_MWh"].mean()
        fig.add_bar(x=d.index, y=d.values, name=f"notice {nh:g} h")
    fig.update_layout(barmode="group", yaxis_title="unserved heat above perfect foresight [MWh]",
                      title="Value of the notification interval — same design, different contract")
    return show(fig, "F12_notice_value")
