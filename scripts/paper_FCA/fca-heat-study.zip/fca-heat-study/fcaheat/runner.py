"""Batch execution, derived KPIs, contract-space and sensitivity studies."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import CFG, OUT_DIR, get_solver
from .data import Inputs
from .model import Case, solve_case


def run_batch(inp: Inputs, sites=None, scenarios=None, fcas=None, years=None,
              resolution=None, overrides=None, tag="main", store_ts=True, verbose=True):
    sites = sites or list(inp.sites["site_id"])
    scenarios = scenarios or CFG["scenarios"]
    fcas = fcas or CFG["fcas"]
    years = tuple(years or CFG["years"])
    resolution = resolution or CFG["resolution"]
    opt = get_solver()
    rows, store = [], {}
    for s in sites:
        for sc in scenarios:
            # the gas baseline does not depend on the connection regime -> run it once
            regimes = ["FCA_FIRM"] if sc == "S0_BASE" else fcas
            for fc in regimes:
                case = Case(site=s, scenario=sc, fca=fc, years=years, resolution=resolution,
                            overrides=overrides or {})
                out = solve_case(inp, case, opt)
                rows.append(out["kpi"])
                if store_ts:
                    store[(s, sc, fc)] = out["ts"]
                if verbose:
                    k = out["kpi"]
                    print(f"  {s:8s} {sc:11s} {fc:16s} peak={k['peak_grid_MW']:6.2f} "
                          f"TES={k['Etes_MWh']:6.1f} BES={k['Ebes_MWh']:6.1f} "
                          f"unserved={k['unserved_MWh']+k['unserved_el_MWh']:8.1f} "
                          f"({k['runtime_s']:.1f}s)")
    kpi = pd.DataFrame(rows)
    kpi.to_csv(OUT_DIR / f"kpi_{tag}.csv", index=False)
    if store_ts:
        pd.to_pickle(store, OUT_DIR / f"ts_{tag}.pkl")
    return kpi, store


def add_relative_kpis(kpi: pd.DataFrame) -> pd.DataFrame:
    k = kpi.copy()
    base = k[k["scenario"] == "S0_BASE"].drop_duplicates("site").set_index("site")
    for src, dst in [("CO2_cert_t", "CO2_cert_base_t"), ("CO2_phys_t", "CO2_phys_base_t"),
                     ("cost_total_EUR", "cost_base_EUR"), ("peak_grid_MW", "peak_base_MW")]:
        k[dst] = k["site"].map(base[src])
    k["dCO2_cert_t"] = k["CO2_cert_base_t"] - k["CO2_cert_t"]
    k["dCO2_phys_t"] = k["CO2_phys_base_t"] - k["CO2_phys_t"]
    k["CO2_red_pct"] = 100 * k["dCO2_phys_t"] / k["CO2_phys_base_t"]
    k["dcost_EUR"] = k["cost_total_EUR"] - k["cost_base_EUR"]
    k["LCOH_EUR_MWh"] = k["dcost_EUR"] / k["E_heat_MWh"].replace(0, np.nan)
    k["abatement_EUR_t"] = k["dcost_EUR"] / k["dCO2_phys_t"].replace(0, np.nan)
    k["uplift_pct"] = 100 * (k["peak_grid_MW"] / k["P_grid_exist_MW"] - 1)
    k["unserved_total_MWh"] = k["unserved_MWh"] + k["unserved_el_MWh"]
    k["feasible"] = k["unserved_total_MWh"] < 1e-3
    k["unserved_share_pct"] = 100 * k["unserved_MWh"] / k["E_heat_MWh"].replace(0, np.nan)
    k["price_advantage_pct"] = 100 * (1 - k["avg_price_EUR_MWh"] / k["mean_price_EUR_MWh"])
    # storage needed per MW of avoided firm capacity, relative to the upgrade case
    up = k[k["fca"] == "FCA_UPGRADE"].set_index(["site", "scenario"])["peak_grid_MW"]
    k["peak_upgrade_MW"] = k.set_index(["site", "scenario"]).index.map(up)
    k["avoided_firm_MW"] = k["peak_upgrade_MW"] - k["P_grid_exist_MW"]
    k["TES_per_avoided_MW"] = k["Etes_MWh"] / k["avoided_firm_MW"].replace(0, np.nan)
    return k


def _unserved(inp, site, scenario, fca, overrides, opt, years=None, resolution=None):
    c = Case(site=site, scenario=scenario, fca=fca, overrides=overrides,
             years=tuple(years or CFG["years"]), resolution=resolution or CFG["resolution"])
    k = solve_case(inp, c, opt)["kpi"]
    return k["unserved_MWh"] + k["unserved_el_MWh"], k


def find_min_flex(inp: Inputs, site: str, scenario: str, fca: str = "FCA_WINDOW",
                  lo=1.0, hi=2.5, tol=0.02, years=None, resolution=None):
    """Smallest P_flex_rel scaling at which the configuration supplies 100 % of the heat."""
    opt = get_solver()
    f = lambda x: _unserved(inp, site, scenario, fca, {"fca.P_flex_rel": float(x)}, opt,
                            years, resolution)[0]
    if f(hi) > 1e-3:
        return np.nan
    if f(lo) <= 1e-3:
        return lo
    while hi - lo > tol:
        mid = 0.5 * (lo + hi)
        if f(mid) > 1e-3:
            lo = mid
        else:
            hi = mid
    return hi


def find_max_restriction(inp: Inputs, site: str, scenario: str, fca: str = "FCA_WINDOW",
                         lo=0.0, hi=16.0, tol=0.5, years=None, resolution=None):
    """Widest restriction block [h per working day] the configuration can still absorb."""
    opt = get_solver()
    f = lambda x: _unserved(inp, site, scenario, fca, {"fca.window_width": float(x)}, opt,
                            years, resolution)[0]
    if f(lo) > 1e-3:
        return np.nan
    if f(hi) <= 1e-3:
        return hi
    while hi - lo > tol:
        mid = 0.5 * (lo + hi)
        if f(mid) > 1e-3:
            hi = mid
        else:
            lo = mid
    return lo


def run_contract_space(inp: Inputs, sites=None, scenarios=("S2_TES", "S3_BES", "S4_TES_BES"),
                       fca: str = "FCA_WINDOW"):
    rows = []
    for s in (sites or list(inp.sites["site_id"])):
        for sc in scenarios:
            mf = find_min_flex(inp, s, sc, fca=fca)
            mr = find_max_restriction(inp, s, sc, fca=fca)
            rows.append(dict(site=s, scenario=sc, min_P_flex_rel=mf, max_restriction_h=mr))
            print(f"  {s:8s} {sc:11s} min P_flex = {mf if mf==mf else float('nan'):.2f} x P_exist"
                  f"   max restriction = {mr if mr==mr else float('nan'):.1f} h/working day")
    df = pd.DataFrame(rows)
    df.to_csv(OUT_DIR / "contract_space.csv", index=False)
    return df


def run_sensitivity_oat(inp: Inputs, site: str, scenario: str, fca: str = "FCA_WINDOW",
                        params=None, years=None, resolution="1h", tag="oat", n_steps=None):
    sens = inp.sensitivity.copy()
    if params:
        sens = sens[sens["param_id"].isin(params)]
    else:
        # drop parameters that cannot act on this LP:
        #   ECON.co2*   -> only affects the gas baseline
        #   fca.notice_h-> only affects the MPC (see mpc.run_mpc_all_sites(notices=...))
        sens = sens[~sens["target"].str.startswith("ECON.co2")]
        sens = sens[sens["target"] != "fca.notice_h"]
    rows = []
    opt = get_solver()
    for _, p in sens.iterrows():
        vals = np.linspace(p["low"], p["high"], int(n_steps or p["n_steps"]))
        for val in vals:
            ov = {p["target"]: float(val if p["mode"] == "absolute" else val)}
            case = Case(site=site, scenario=scenario, fca=fca,
                        years=tuple(years or CFG["years"]), resolution=resolution, overrides=ov)
            out = solve_case(inp, case, opt)
            k = out["kpi"]; k.update(param_id=p["param_id"], value=float(val),
                                     base=float(p["base"]), mode=p["mode"])
            rows.append(k)
        print(f"  {p['param_id']:16s} done ({len(vals)} runs)")
    df = pd.DataFrame(rows)
    df.to_csv(OUT_DIR / f"sensitivity_{tag}_{site}_{scenario}_{fca}.csv", index=False)
    return df
