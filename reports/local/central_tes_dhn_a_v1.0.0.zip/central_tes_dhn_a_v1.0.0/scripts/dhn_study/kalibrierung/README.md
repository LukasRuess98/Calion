# Calibration of the equivalent network (variants A, B, C)

`kalibrierung_kanten.csv`: calibrated resistance K of each edge (supply + return, bar/(kg/s)²) of the three
equally good calibration variants used in the paper (A = reference, B and C = sensitivity). `K_prior` and
`Multiplikator` refer to the placeholder geometry in `netzmodell.KANTEN` and carry no information.

`kalibrierung_last_versatz.csv`: load-group weights, base-load shifts and station offsets are NOT published
(neutral values 1 / 0 / 0). Node and edge ids are anonymised; the topology corresponds to Fig. 1 of the paper.
