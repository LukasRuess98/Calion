"""Calibration I/O of the equivalent network (trimmed for the data publication).

The calibration driver of the study (fit of the edge resistances to the measured pressures and flows of 2025) needs the
measured data set and is not part of this package; the fit itself is ``netzmodell.kalibriere``. This module keeps the
functions the study code uses: the location of the published calibration and reading / writing a calibration.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from . import netzmodell as nm

KALIBRIERUNG_REPO = Path(__file__).resolve().parent / "kalibrierung"   # published calibration (variants A, B, C)
MINDEST_MITTE = 1.0                                                   # minimum Δp at the city/centre stations [bar]


def speichere_kalibrierung(kal: dict, nz: nm.Netz, ordner: Path) -> None:
    """Calibration as CSV: resistance per edge plus load weights, base-load shifts and station offsets."""
    ordner.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"Multiplikator": kal["multiplikator"], "K [bar/(kg/s)²]": kal["K"],
                  "K_prior": nz.k0}).rename_axis("Kante").to_csv(ordner / "kalibrierung_kanten.csv")
    pd.Series({**{f"Gewicht {k}": v for k, v in kal["gewichte"].items()},
               **{f"Grundlast {k} [kg/s]": v for k, v in kal["grundlast"].items()},
               **{f"Versatz {k} [bar]": v for k, v in kal["versatz"].items()}}).to_csv(ordner / "kalibrierung_last_versatz.csv")


def lade_kalibrierung(out, nz: nm.Netz) -> dict:
    """Restore a calibration from its CSV files."""
    k = pd.read_csv(out / "kalibrierung_kanten.csv", index_col=0)
    lv = pd.read_csv(out / "kalibrierung_last_versatz.csv", index_col=0).iloc[:, 0]
    sub = lambda pre, suf="": {i[len(pre):].replace(suf, ""): float(v) for i, v in lv.items() if i.startswith(pre)}  # noqa: E731
    return {"K": k.loc[nz.kanten_ids, "K [bar/(kg/s)²]"].to_numpy(), "multiplikator": k.loc[nz.kanten_ids, "Multiplikator"],
            "gewichte": sub("Gewicht "), "grundlast": sub("Grundlast ", " [kg/s]"),
            "versatz": pd.Series(sub("Versatz ", " [bar]")), "erfolg": True, "kosten": float("nan")}
