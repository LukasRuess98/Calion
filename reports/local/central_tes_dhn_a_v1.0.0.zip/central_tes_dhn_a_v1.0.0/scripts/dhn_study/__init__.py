"""Shared modules of the DHN-A analyses used by the central-TES study (data publication subset).

* ``daten``                     data loading, water properties, corrected generation per plant
* ``hydraulik``                 plant mass flows and pressure-coupling helpers
* ``netzmodell``                hydraulic equivalent network (meshed, supply + return) and its calibration
* ``run_netzmodell``            calibration I/O (published calibration in ``kalibrierung/``)
* ``gegenrechnung_pandapipes``  independent pandapipes model of the equivalent network
* ``central_tes``               the study (MILP, coupling, rolling horizon, sensitivities, tables, figures)
"""
