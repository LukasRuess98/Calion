"""Tests run on the SYNTHETIC example unless CENTRAL_TES_CONFIG points to another configuration."""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("CENTRAL_TES_CONFIG", "configs/central_tes/synthetic.yaml")
if not (ROOT / "data" / "synthetic" / "measurements_2025_hourly.parquet").exists():
    from scripts.dhn_study.central_tes import synthetic_data
    synthetic_data.write(ROOT / "data" / "synthetic", 2025, "2025-01-01 00:00", "2025-02-28 23:00")
