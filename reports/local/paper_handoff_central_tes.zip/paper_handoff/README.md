# Paper hand-over package — central TES with two industrial prosumers (DHN-A)

Status 2026-10-12 (south expansion reframed as hosting capacity without new capacity — author decision; writer items and literature values done). Rolling-horizon results re-run with a leak-free price forecast; foresight decomposition, storage-model
bracket and differential-pressure sign analysis added for the literature contrasts (brief section 11, results section 10).
Everything here is anonymised.

Start with **`paper_writing_brief.md`**: storyline, contributions, methods summary, key numbers per result section,
hypothesis verdicts, figure and table plan, limitations, literature pointers and the anonymisation rules.

| Folder / file | Content |
|---|---|
| `paper_writing_brief.md` | the brief for the writing session (self-contained) |
| `docs/paper_tables.md` | generated result tables T1–T7, T4b and T7b (inputs, factorial, Shapley, foresight and its decomposition, size × power, sensitivities, expansion) |
| `docs/paper_figures.md` | what each figure shows and the numbers printed in it |
| `docs/results_v2.md` | full results log incl. review history (sections 1–9) and literature contrasts (section 10) |
| `docs/model_and_deviations.md` | model equations, hydraulic control and limits, coupling, deviations D1–D21, literature |
| `docs/literature_check.md` | cost and price assumptions with sources |
| `docs/hydraulic_calibration.md` | calibration and holdout validation of the hydraulic model |
| `docs/paper_readiness.md` | check of the study design (RQ, hypotheses, experiments) against the results |
| `figures/` | fig0–fig7 as vector PDF (fonts embedded) and 600 dpi PNG; figure system v2: Latin Modern Roman, institute colour roles, labels CHP / WH / GT / BCHP / GB |
| `data/` | aggregated result tables (CSV/JSON) behind every number, for checks while writing |

Mapping figure files → proposed paper figures: fig0 → Fig. 1, fig1 → Fig. 2, fig2 → Fig. 3, fig7 → Fig. 4,
fig3 → Fig. 5, fig5 (south hosting) → Fig. 6, fig6 → Fig. 7, fig4 → Fig. 8.

Rules: no new results in the writing session; every number from `docs/paper_tables.md` or `docs/results_v2.md`;
keep all names anonymised (DHN-A, the operator, KWK, MVA, GT, Bio-KWK, HW1, HW2, PS1, PS2, V01–V24, site S,
partner A, partner B).
