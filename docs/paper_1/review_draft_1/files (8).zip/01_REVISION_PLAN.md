# Revision plan v2

## Strategy

The reviewers converge on two structural criticisms: several comparisons change
more than one factor at once, and the contribution reads as a structured
comparison of established models. We answer the first with a topology × physics
factorial plus two new model cells, and the second by changing what the paper
measures — from **estimation bias** (objective differences between formulations)
to **decision regret** (the cost of having decided with the simpler model,
evaluated under a common high-fidelity forward model). A second real network with
distributed generation, measured pressure, and roughly an order of magnitude more
pipe turns three of the reviewers' scope objections into experimental factors.

## Structure

Current 7 sections → 5, per AE house style:

```
1. Introduction              (absorbs Related work)
2. Methodology               2.1 factorial + reference definitions
                             2.2 base formulation · 2.3 extended physics
                             2.4 forward evaluator and regret   ← NEW
                             2.5 validation protocol · 2.6 implementation
3. Case studies              3.1 Memmingen legacy · 3.2 Stadtbach
                             3.3 Memmingen upgraded · 3.4 synthetic factorial
4. Results and discussion    4.1 validation (thermal + hydraulic)
                             4.2 bias decomposition
                             4.3 regret and physical feasibility   ← NEW
                             4.4 generation topology as moderator  ← NEW
                             4.5 hydraulics · 4.6 linearisation and delay
                             4.7 generalisability and out-of-sample prediction
                             4.8 sensitivity and robustness
                             4.9 computational performance
                             4.10 implications · 4.11 limitations
5. Conclusions               (no subheadings)
```

## Risk register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| `T0P1` recovers most of the bias | **High** | Title changes | Pre-committed; transferability argument prepared |
| Regret ≈ 0 everywhere | Medium | Headline changes | "Biased estimators, competent controllers" — arguably the better paper; ties to the CO2-policy section |
| Stadtbach `topo_main` also ≈ 0 | Medium | Moderator claim fails | Then it is a *more* surprising result; write both sentences before looking |
| P12 unknowns unresolvable (no elevations, no shaft mapping) | Medium | Hydraulic validation weakens | Fall back to literature comparison; state limitation; request data from swa early |
| Out-of-sample prediction fails | Medium | Rules weaken | Report honestly; a failed extrapolation is informative and pre-committed |
| Pump fix pushes hydraulics above 1 % | Medium | Abstract wording | Ordering survives; restate magnitude |
| Reviewer reads reframing as evasion | Low | — | Response letter names every changed conclusion |
| Scope creep — two networks, new metric, 20 days | **High** | Missed deadline | **Request extension** (below) |

## Minimum viable scope if time is cut

Non-negotiable: **P1, P3, P11, P4 (Cases A and B), P7** plus editorial.
Those cover R2.2, R2.3, R2.4 and R2.1. Defer: Case C, the synthetic generation-
topology factor, the pandapipes cross-check.

## Timeline

Deadline 2026-08-29 — 20 days. The critical path (P12 discovery → hydraulic
validation → evaluator → re-runs of both networks → 648 synthetic runs → analysis
→ figures → rewrite) does not fit, and the reframing touches the Introduction,
contributions, Results and Conclusions.

**Request an extension to mid/late October:**

> We are grateful for the constructive reviews. Responding properly to Reviewer 2's
> comments 1 to 4 requires more than an incremental revision: we are adding a
> decision-regret evaluation, two model formulations that isolate effects the
> original design confounded, and a second real district heating network with
> measured pressure data that addresses the hydraulic-validation concern directly.
> We therefore request an extension until [date] to submit a revision that
> addresses the comments substantively.

## Also confirm

Letter is **APEN-D-26-15734**; PDF header reads **APEN-S-26-20346**. Confirm which
record the revision uploads against.
