# P6 — Robustness: clustering, calibration, holdout

**Depends on:** P1, P2, P11 · **Blocks:** P7
**Output:** `results/v2/robustness/…`, `revision/audit/P6_robustness.md`

## Part A — Alternative zone aggregations (R1.6)

"Alternative clustering methods could yield different spatial routing and loss
distributions even when total annual losses are preserved."

For Memmingen, three named clusterings plus a null distribution, all preserving
ΣU·L = 1011 W/K:
1. `T1_branch` — current (adjacent nodes sharing a branch segment)
2. `T1_distance` — k-medoids on path distance from source
3. `T1_demand` — balanced annual demand per zone
4. `T1_random` × 10 — contiguous random partitions

Run `T1P1` for each (and `T1P0` for 1–3). Report `cost(T2P1) − cost(T1P1)` and
the spread across the random partitions (Figure F12), with the `loss_main`
magnitude drawn as a reference line so the reader sees the scale immediately.

For **Stadtbach**, `T1` is fixed by the shaft resolution and is not a free choice
— note this in the paper: the aggregation is dictated by the metering, which is
the argument in `04_NOVELTY_STATEMENT.md` §4.

Re-check the warm-year sign reversal (v1: L2−L3 = −2.2 %) across all clusterings.
If it appears in all, it is structural; if in one, v1's explanation
("loss-aggregation artefact of L2's zone approximation") needs revising.

## Part B — Calibration robustness and out-of-sample validation (R2.4)

**A problem v1 shipped with:** the BCM cross-check calibrates the ×1.330
multiplier on the Oct–Feb subset and then reports MAE 1.56 °C, RMSE 2.15 °C **on
that same subset** (n = 3173). That is in-sample error presented as validation.
R2 asked for "additional out-of-sample validation where possible" and may well
have seen this.

**Required:**
1. **Temporal holdout** — calibrate on heating season 1, validate on season 2.
   Report both, side by side, and state the degradation.
2. **Spatial holdout** — apply the same calibration/validation node discipline
   already used for the MIQCP to the BCM.
3. Report in-sample and out-of-sample metrics together everywhere. A stated
   degradation is safe; an unstated in-sample number is not.

**Multiplier plausibility.** v1 has two calibrations that disagree badly: BCM
global ×1.330 versus branch-sequential terminal pipe at ×4.7 nominal. A ×4.7
multiplier on nominal EN 253 U-values is not defensible as insulation ageing — it
is absorbing something else, most likely unmodelled service-pipe and substation
losses.

4. Re-run the branch-sequential calibration with multipliers bounded to a
   defensible band (recommend `[0.8, 2.0]`, justified from EN 253 ageing
   literature) and route the residual into an explicit `service_pipe_loss` term
   per consumer node.
5. Run `T2P1` and `T2P2` under both calibrations; report the decomposition under
   each. **The point to establish: the conclusion is not an artefact of a
   permissive calibration.** If the two disagree materially, that is a genuine
   limitation and must be stated, not buried.
6. Write the reconciliation paragraph for `GAP:CALIB-RECONCILE`: why forward-physics
   BCM and dispatch-model calibration differ, what each is fitted to, and why both
   are kept. v1 asserted "both methods are valid for their respective purposes"
   without explaining a factor-3.5 discrepancy; that will not survive round two.

## Part C — Flow error decomposition

v1 reports 36 % flow MAPE against a ±15 % instrument error and sets no gate.
Decompose: systematic bias vs dispersion, by load band, and energy-weighted
versus unweighted. A 36 % number with no gate reads as an unexamined failure;
explained, it is fine.

## Report

`revision/audit/P6_robustness.md`: clustering table and spread; calibration
comparison with in-sample and out-of-sample metrics; flow-error decomposition;
the reconciliation paragraph.
