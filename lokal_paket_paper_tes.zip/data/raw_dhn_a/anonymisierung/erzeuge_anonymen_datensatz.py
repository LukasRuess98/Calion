"""LOKAL (nicht versioniert): erzeugt den anonymisierten Datensatz data/dhn_a/ aus den Rohdaten.

Enthält die Zuordnung Klarname → anonyme ID und darf nicht ins Repository.
"""
import io, glob, zipfile, json
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[3]
RAW = ROOT / "data" / "raw_dhn_a" / "upload" / "A_Daten"
OUT = ROOT / "data" / "dhn_a"; OUT.mkdir(parents=True, exist_ok=True)
HERE = Path(__file__).resolve().parent

KUNDEN = ["Am_MIttleren_Moos", "August-Wessels-Str", "Beethovenpark", "Don_Bosco", "Fraunhofer", "Fuggerstr", "Grasiger_Weg",
          "Hans-Boeckler-Str", "Hooverstr", "Hoher_Weg", "Hunoldsgraben", "Josefinum", "KUKA", "Klinikum", "Kreissparkasse",
          "Kurt-Schumacher-Str", "Lechhauser_Str", "Liste-Meitner-Str", "MAN", "SIGMA_Technopark", "Schlettererstr",
          "Siegfried_Aufhaeuser-Str", "Theodor-Heuss-Platz", "UNI"]
REGION = {"Am_MIttleren_Moos": "Ost-L5", "August-Wessels-Str": "Sekundärnetz West", "Beethovenpark": "Süd (Stichleitungsende)",
          "Don_Bosco": "Mitte-L3", "Fraunhofer": "Süd", "Fuggerstr": "City", "Grasiger_Weg": "Sekundärnetz West",
          "Hans-Boeckler-Str": "Ost-L5", "Hooverstr": "Sekundärnetz West", "Hoher_Weg": "City", "Hunoldsgraben": "City",
          "Josefinum": "Sekundärnetz West", "KUKA": "Ost-L7", "Klinikum": "Sekundärnetz West", "Kreissparkasse": "City",
          "Kurt-Schumacher-Str": "Ost-L5", "Lechhauser_Str": "Mitte-L3", "Liste-Meitner-Str": "Sekundärnetz West",
          "MAN": "Ost-L5 (Speicherstandort S)", "SIGMA_Technopark": "Süd", "Schlettererstr": "L1", "Siegfried_Aufhaeuser-Str": "Sekundärnetz West",
          "Theodor-Heuss-Platz": "Mitte-L4", "UNI": "Süd"}
rng = np.random.default_rng(20261001)
perm = rng.permutation(len(KUNDEN))
VID = {k: f"V{int(i)+1:02d}" for k, i in zip(KUNDEN, perm)}
ERZ = {"HKW": "gas_CHP", "AVA": "waste_incineration", "GT-Ost": "gas_turbine", "BMHKW": "biomass_CHP",
       "Heizwerk_Sued": "boiler_plant_1", "PPS": "pump_station_1", "PSW": "pump_station_2"}
Q = {"Druck_VL": "p_supply", "Druck_RL": "p_return", "DiffDruck": "dp", "Temp_VL": "T_supply", "Temp_RL": "T_return",
     "Durchfluss": "flow", "Waermeleistung": "heat"}

def neu(c):
    if c.startswith("HKW_Durchfluss_SL"): return f"gas_CHP_flow_line_{c[-1]}"
    if c == "HKW_Durchfluss_gesamt": return "gas_CHP_flow_total_out"
    if c == "HWW_Waermeleistung_Kessel": return "boiler_plant_2_heat_boilers"
    if c.startswith("HWW_") and c.endswith("_Primeinsp"):
        q = c[4:-len("_Primeinsp")]; return f"boiler_plant_2_hx_{Q[q]}"
    if c.startswith("HWW_Durchfluss_Sek"): return f"boiler_plant_2_secondary_flow_{c[-1]}"
    if c == "HWW_Waermeleistung_Sek_Aussp": return "boiler_plant_2_secondary_heat"
    if c.startswith("HWW_"): return f"boiler_plant_2_secondary_{Q[c[4:]]}"
    for pre in ("PPS", "PSW"):
        if c.startswith(pre + "_"):
            r = c[len(pre) + 1:]
            r = (r.replace("Drehzahl_NUP", "speed_").replace("DiffDruck_VL_nach_Pumpe", "dp_supply_after_pump")
                  .replace("DiffDruck_VL_vor_Pumpe", "dp_supply_before_pump").replace("Druck_VL_nach_Pumpe", "p_supply_after_pump")
                  .replace("Druck_VL_vor_Pumpe", "p_supply_before_pump").replace("Durchfluss_RL_nach_Mitte", "flow_return_to_center")
                  .replace("Durchfluss_RL_nach_Sued", "flow_return_to_south").replace("Durchfluss_RL_nach_West", "flow_return_to_west")
                  .replace("Temp_VL", "T_supply").replace("Temp_RL", "T_return"))
            return f"{ERZ[pre]}_{r}"
    for pre, name in ERZ.items():
        if c.startswith(pre + "_"):
            return f"{name}_{Q[c[len(pre)+1:]]}"
    if c.startswith("Lechhauser_Str_HA_"): return f"{VID['Lechhauser_Str']}_house_{Q[c[len('Lechhauser_Str_HA_'):]]}"
    for k in sorted(KUNDEN, key=len, reverse=True):
        if c.startswith(k + "_"):
            q = c[len(k) + 1:].replace("_Station", "")
            return f"{VID[k]}_{Q[q]}"
    raise KeyError(c)

a = pd.read_parquet(RAW / "acron_stundenwerte_wert.parquet")
m = {c: neu(c) for c in a.columns}
assert len(set(m.values())) == len(m), "Namenskollision"
b = a.rename(columns=m); b.index.name = "time_local"
b = b[sorted(b.columns)]
b.to_parquet(OUT / "measurements_2025_hourly.parquet", compression="zstd")
pd.DataFrame({"klarname": list(m), "anonym": list(m.values())}).to_csv(HERE / "zuordnung_signale.csv", index=False)
pd.DataFrame({"klarname": KUNDEN, "anonym": [VID[k] for k in KUNDEN], "region": [REGION[k] for k in KUNDEN]}).to_csv(HERE / "zuordnung_verbraucher.csv", index=False)
# Verbraucher-Metadaten (ohne Klarnamen)
meta = pd.DataFrame({"id": [VID[k] for k in KUNDEN], "region": [REGION[k] for k in KUNDEN]}).sort_values("id")
meta["note"] = ""
meta.loc[meta.id == VID["Lechhauser_Str"], "note"] = "zusätzlich Hausanschluss-Signale (_house_)"
meta.loc[meta.id == VID["Beethovenpark"], "note"] = "Ende einer langen Stichleitung"
meta.loc[meta.id == VID["MAN"], "note"] = "Großkunde, Speicherstandort S der Studie"
meta.to_csv(OUT / "consumers.csv", index=False)
# Lastgaenge
raw = pd.read_excel(RAW / "250519_tex_Lastgänge 2020_2022.xlsx", header=None, skiprows=8).iloc[:, :5]
raw.columns = ["Datum", "Zeit", "y2022", "y2021", "y2020"]
lg = pd.DataFrame({f"generation_MW_{y}": pd.to_numeric(raw[f"y{y}"], errors="coerce").to_numpy() for y in (2020, 2021, 2022)})
lg.insert(0, "hour_of_year", np.arange(len(lg)))
lg.to_csv(OUT / "generation_profiles_2020_2022_hourly.csv", index=False, float_format="%.1f")
# Aussentemperatur (DWD), ohne Stationsangabe
import sys; sys.path.insert(0, str(ROOT))
from scripts.dhn_study import wetter
ta = wetter.lade_dwd("00232", download=False)
ta["2019-01-01":].rename("T_ambient").to_frame().rename_axis("time_local").to_parquet(OUT / "ambient_temperature_hourly.parquet", compression="zstd")
ta.resample("D").mean().rename("T_ambient_daily_mean").to_frame().rename_axis("date").to_csv(OUT / "ambient_temperature_daily.csv", float_format="%.2f")
print("ok", b.shape, len(lg), OUT)
print({k: VID[k] for k in KUNDEN})
