"""LOKAL (nicht versioniert): ersetzt Klarnamen in den Studiendokumenten durch anonyme Bezeichnungen."""
import re, sys
from pathlib import Path
import pandas as pd
HERE = Path(__file__).resolve().parent
sig = pd.read_csv(HERE / "zuordnung_signale.csv")
V = dict(pd.read_csv(HERE / "zuordnung_verbraucher.csv")[["klarname", "anonym"]].values)

def anonymisiere(t: str) -> str:
    # 1) Pfade, Dateien, Branches
    for a, b in [("docs/studie_MAN_UPM/", "docs/dhn_storage_study/"), ("Review_Studie_MAN_UPM.md", "Review_Speicherstudie.md"),
                 ("scripts/studie_MAN_UPM", "scripts/dhn_study"), ("scripts.studie_MAN_UPM", "scripts.dhn_study"),
                 ("tests/test_studie_man_upm_analyse.py", "tests/test_dhn_study.py"), ("results/studie_MAN_UPM", "results/dhn_study"),
                 ("data/Stadtbach/upload/A_Daten/", "data/dhn_a/"), ("data/Stadtbach/upload/", "data/dhn_a/"), ("data/Stadtbach/", "data/dhn_a/"),
                 ("`studie_grosswaermespeicher_MAN_UPM.ipynb`", "Studien-Notebook"), ("studie_grosswaermespeicher_MAN_UPM.ipynb", "Studien-Notebook"),
                 ("`claude/busy-shannon-9uws43`", "Studien-Branch"), ("claude/busy-shannon-9uws43", "Studien-Branch"),
                 ("`acron_stundenwerte_wert.parquet`", "`measurements_2025_hourly.parquet`"), ("acron_stundenwerte_wert.parquet", "measurements_2025_hourly.parquet"),
                 ("`250519_tex_Lastgänge 2020_2022.xlsx`", "`generation_profiles_2020_2022_hourly.csv`"),
                 ("`acron_stundenwerte_minmax`", "Stunden-Min/Max-Export"), ("acron_stundenwerte_minmax", "Stunden-Min/Max-Export"),
                 ("`Import_Data_stadtbach_15min`", "15-min-Importdaten"), ("Import_Data_stadtbach_15min", "15-min-Importdaten"),
                 ("`configs/paper_2/Stadtbach_topo.yaml`", "Topologie-YAML des Frameworks"), ("Stadtbach_topo.yaml", "Topologie-YAML"),
                 ("Topo-YAML", "Topologie-YAML")]:
        t = t.replace(a, b)
    # 2) Signalnamen (längste zuerst)
    for k, v in sorted(zip(sig.klarname, sig.anonym), key=lambda x: -len(x[0])):
        t = t.replace(k, v)
    t = re.sub(r"\bacron\[", "m[", t); t = re.sub(r"\bacron\.", "m.", t); t = t.replace("acron", "m")
    t = t.replace("ACRON", "Leitsystem")
    # 3) Standort/Betreiber/Ort
    for a, b in [("Stadtbach (swa)", "DHN-A"), ("Netz Stadtbach", "Netz DHN-A"), ("Fernwärmenetz Stadtbach", "Fernwärmenetz DHN-A"), ("Stadtbach", "DHN-A"),
                 ("swa", "Betreiber"), ("MAN/UPM", "Standort S"), ("DWD-Station Augsburg", "DWD-Referenzstation"),
                 ("Station 00232 **Augsburg**", "Referenzstation"), ("Station 00232", "Referenzstation"), ("Station Augsburg", "Referenzstation"),
                 ("Augsburger", "lokale"), ("Augsburg", "Referenzstation"), ("OpenData Bayern", "OpenData der Landesvermessung"), ("Bayern", "Land")]:
        t = t.replace(a, b)
    # 4) Pläne
    t = re.sub(r"WV ?640( Bl\. ?3)?", "Plan A", t); t = re.sub(r"WV ?650", "Plan B", t); t = re.sub(r"WV ?660", "Plan C", t)
    # 5) Verbraucher (Klarnamen in Prosa)
    prosa = {"Fraunhofer": "V06", "Hoher Weg": "V03", "Hunoldsgraben": "V10", "Fuggerstr.": "V24", "Fuggerstr": "V24",
             "Theodor-Heuss-Platz": "V12", "Theodor-Heuss-Pl.": "V12", "Schlettererstr.": "V23", "Schlettererstr": "V23",
             "Lechhauser Str.": "V15", "Lechhauser": "V15", "Hans-Böckler-Str.": "V11", "Hans-Böckler": "V11", "Kurt-Schumacher": "V08",
             "Am Mittleren Moos": "V18", "KUKA": "V07", "Kreissparkasse": "V17", "SIGMA": "V14", "Beethovenpark": "V01", "Klinikum": "V13",
             "Don Bosco": "V19", "Josefinum": "V09", "Hooverstr": "V04", "Grasiger Weg": "V02", "Siegfried-Aufhäuser": "V21",
             "Lise-Meitner": "V16", "August-Wessels": "V20"}
    for k in sorted(prosa, key=len, reverse=True):
        t = t.replace(k, prosa[k])
    for k, v in V.items():
        t = re.sub(rf"\b{re.escape(k)}\b", v, t)
    t = re.sub(r"\bUNI\b", "V05", t)
    # 6) Erzeuger und Pumpstationen nach Typ
    for a, b in [("BM-HKW", "Bio-KWK"), ("BMHKW", "Bio-KWK"), ("Biomasse-HKW", "Bio-KWK"), ("GT-Ost", "GT"), ("Heizwerk Süd", "HW1"), ("Heizwerk West", "HW2"),
                 ("Pumpstation Süd", "PS1"), ("Pumpstation West", "PS2"), ("AVA-Übernahme", "MVA"), ("Heizkraftwerk", "KWK-Hauptanlage")]:
        t = t.replace(a, b)
    for a, b in [("HKW", "KWK"), ("AVA", "MVA"), ("HWS", "HW1"), ("HWW", "HW2"), ("PSS", "PS1"), ("PPS", "PS1"), ("PSW", "PS2"), ("BM", "Bio-KWK"), ("UPM", "S")]:
        t = re.sub(rf"\b{a}\b", b, t)
        t = re.sub(rf"\b{a}_", b + "_", t)
    # 7) Speicherstandort MAN
    t = re.sub(r"\bam MAN\b", "am Standort S", t); t = re.sub(r"\bMAN-", "S-", t); t = re.sub(r"\bMAN\b", "S", t); t = re.sub(r"\bJMAN\b", "J_S", t)
    # 8) Modellknoten, Sektionen, Stammleitungen
    for a, b in [("SEC2", "N_City"), ("SEC3", "N_L3"), ("SEC4", "N_L4"), ("SUED", "N_Süd"), ("SL1G", "N_L1"), ("SL5M", "N_L5a"), ("SL5O", "N_L5b"),
                 ("SL6S", "N_L6"), ("SL7G", "N_L7"), ("K001", "K1"), ("KNEU", "K2"), ("K338", "K3"), ("K818", "K4"), ("N773", "K5"),
                 ("DOM/CITY", "City"), ("DOM", "City"), ("CITY", "City"), ("STAWA", "Mitte-L3"), ("ULRICH", "Mitte-L4")]:
        t = re.sub(rf"\b{re.escape(a)}\b", b, t)
    t = re.sub(r"\bSL([1-7])", r"L\1", t)
    # 9) Armaturennummern
    nummern = {}
    def arm(mo):
        k = mo.group(0); nummern.setdefault(k, f"A{len(nummern) + 1}"); return nummern[k]
    t = re.sub(r"\b\d{3}\.(?:\d|x)(?:/\d{3}\.\d)?\b", arm, t)
    return t

for f in sys.argv[1:]:
    p = Path(f); p.write_text(anonymisiere(p.read_text(encoding="utf-8")), encoding="utf-8"); print("anonymisiert:", p)
