"""
Interactive browser for saved workflow simulations.

This module provides a Panel-based dashboard that allows browsing and
visualizing previously saved workflow results from outputs/workflows/.

Usage:
    from calion.io.workflow_browser import create_workflow_browser

    browser = create_workflow_browser(saved_workflows_dir="outputs/workflows")
    browser.show()  # Or use: panel serve notebook.ipynb --show
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import pandas as pd

try:
    import panel as pn
    HAVE_PANEL = True
except ImportError:
    HAVE_PANEL = False
    pn = None

try:
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots  # noqa: F401
    HAVE_PLOTLY = True
except ImportError:
    HAVE_PLOTLY = False
    go = None

__all__ = ["HAVE_PANEL", "HAVE_PLOTLY", "create_workflow_browser"]

logger = logging.getLogger(__name__)


def create_workflow_browser(
    saved_workflows_dir: str | None = None,
    title: str = "CALION Workflow Browser"
) -> Any:
    """
    Create an interactive browser for saved workflow simulations.

    This creates a Panel dashboard with:
    - Dropdown to select saved simulations
    - All standard dashboard tabs (Overview, Zeitreihen, Kosten, Anlagen)
    - Access to CSV timeseries and exported plots
    - Comparison between multiple simulations

    Parameters
    ----------
    saved_workflows_dir : str, optional
        Directory containing saved workflows (default: "outputs/workflows")
    title : str
        Browser title

    Returns
    -------
    pn.Column
        Panel browser dashboard

    Examples
    --------
    >>> from calion.io.workflow_browser import create_workflow_browser
    >>> browser = create_workflow_browser()
    >>> browser  # Display in Jupyter

    Or serve as webapp:
    >>> import panel as pn
    >>> browser = create_workflow_browser()
    >>> pn.serve(browser, port=5007, show=True)
    """

    if not HAVE_PANEL:
        raise ImportError(
            "Panel is required for workflow browser. Install with: pip install panel holoviews bokeh"
        )

    # Initialize Panel
    pn.extension('plotly', 'tabulator', sizing_mode='stretch_width')

    # Resolve directory (supports legacy path detection)
    from calion.io._output_paths import resolve_workflows_dir
    resolved_dir = resolve_workflows_dir(saved_workflows_dir)

    # Create browser instance
    browser = WorkflowBrowser(resolved_dir, title)

    return browser.create()


class WorkflowBrowser:
    """Interactive browser for saved workflows."""

    def __init__(self, saved_workflows_dir: str, title: str):
        self.saved_workflows_dir = Path(saved_workflows_dir)
        self.title = title

        # Scan for available workflows
        self.available_workflows = self._scan_workflows()

        if not self.available_workflows:
            logger.warning(f"No workflows found in {saved_workflows_dir}")

        # Current selection
        self.current_workflow = None
        self.current_workflow_data = None

    def _scan_workflows(self) -> list[dict[str, Any]]:
        """Scan saved_workflows directory for available simulations."""

        if not self.saved_workflows_dir.exists():
            logger.warning(f"Directory {self.saved_workflows_dir} does not exist")
            return []

        workflows = []

        for workflow_dir in self.saved_workflows_dir.iterdir():
            if not workflow_dir.is_dir():
                continue

            # Check for metadata.json (preferred) or manifest.json (fallback)
            metadata_file = workflow_dir / 'metadata.json'
            manifest_file = workflow_dir / 'manifest.json'

            if metadata_file.exists():
                try:
                    with open(metadata_file, encoding='utf-8') as f:
                        metadata = json.load(f)

                    # Extrahiere Daten mit Fallbacks
                    name = metadata.get('name', workflow_dir.name)
                    saved_at = metadata.get('saved_at', '')

                    # Szenario-Name aus verschachtelter Struktur
                    scenario_data = metadata.get('scenario', {})
                    if isinstance(scenario_data, dict):
                        scenario = scenario_data.get('name', scenario_data.get('title', 'unknown'))
                    else:
                        scenario = 'unknown'

                    # Kosten aus costs-Dictionary
                    costs_data = metadata.get('costs', {})
                    if isinstance(costs_data, dict):
                        costs = costs_data.get('total_eur', 0.0)
                    else:
                        costs = 0.0

                    # Steps aus workflow-Dictionary
                    workflow_data = metadata.get('workflow', {})
                    if isinstance(workflow_data, dict):
                        steps = workflow_data.get('steps', [])
                    else:
                        steps = []

                    workflows.append({
                        'path': workflow_dir,
                        'name': name,
                        'date': saved_at,
                        'scenario': scenario,
                        'costs': costs,
                        'steps': steps,
                        'metadata': metadata
                    })
                except Exception as e:
                    logger.warning(f"Failed to load metadata from {metadata_file}: {e}")

            elif manifest_file.exists():
                # Fallback: use manifest.json (from export_workflow_results)
                try:
                    with open(manifest_file, encoding='utf-8') as f:
                        manifest = json.load(f)

                    # Extract data from manifest format
                    name = manifest.get('scenario_title', workflow_dir.name)
                    saved_at = manifest.get('export_timestamp', '')
                    scenario = manifest.get('scenario_title', manifest.get('slug', 'unknown'))
                    steps = manifest.get('workflow_steps', [])

                    workflows.append({
                        'path': workflow_dir,
                        'name': name,
                        'date': saved_at,
                        'scenario': scenario,
                        'costs': 0.0,  # Not available in manifest
                        'steps': steps,
                        'metadata': manifest
                    })
                except Exception as e:
                    logger.warning(f"Failed to load manifest from {manifest_file}: {e}")
            else:
                # Fallback: use directory name
                workflows.append({
                    'path': workflow_dir,
                    'name': workflow_dir.name,
                    'date': '',
                    'scenario': 'unknown',
                    'costs': 0.0,
                    'steps': [],
                    'metadata': {}
                })

        # Sort by date (newest first)
        workflows.sort(key=lambda w: w['date'], reverse=True)

        return workflows

    def _load_workflow(self, workflow_info: dict[str, Any]) -> Any | None:
        """Load workflow from saved_workflows directory."""

        from calion.io.notebook_helpers import load_workflow_from_saved

        try:
            workflow = load_workflow_from_saved(workflow_info['path'], verbose=False)
            logger.info(f"Loaded workflow: {workflow_info['name']}")
            return workflow
        except Exception as e:
            logger.error(f"Failed to load workflow {workflow_info['name']}: {e}")
            return None

    def _load_timeseries_csv(self, workflow_info: dict[str, Any], result_type: str = 'rh') -> pd.DataFrame | None:
        """Load timeseries CSV for a workflow."""

        csv_file = workflow_info['path'] / f'{result_type}_timeseries.csv'

        if not csv_file.exists():
            logger.warning(f"CSV not found: {csv_file}")
            return None

        try:
            df = pd.read_csv(csv_file, index_col=0, parse_dates=True)
            logger.info(f"Loaded {result_type} timeseries: {len(df)} rows, {len(df.columns)} columns")
            return df
        except Exception as e:
            logger.error(f"Failed to load CSV {csv_file}: {e}")
            return None

    def create(self) -> pn.Column:
        """Create the browser dashboard."""

        if not self.available_workflows:
            return pn.Column(
                pn.pane.Markdown(f"# {self.title}"),
                pn.pane.Markdown(
                    f"## WARNUNG: Keine gespeicherten Workflows gefunden\n\n"
                    f"Verzeichnis: `{self.saved_workflows_dir}`\n\n"
                    f"**Erstelle Workflows mit:**\n"
                    f"- `notebooks/scenario_studio.ipynb`\n"
                    f"- `notebooks/runner.ipynb`\n\n"
                    f"Workflows werden automatisch in `outputs/workflows/` gespeichert."
                )
            )

        # Professional technical header - Tabellenbuch style
        header = pn.pane.Markdown(
            f"""
<div style="background: linear-gradient(135deg, #004191 0%, #002855 100%);
            padding: 25px 35px;
            border-radius: 0;
            color: white;
            margin-bottom: 0;
            border-bottom: 4px solid #FFD800;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);">
    <div style="display: flex; align-items: center; justify-content: space-between;">
        <div style="flex: 1;">
            <div style="display: flex; align-items: baseline; gap: 15px;">
                <h1 style="margin: 0; font-size: 32px; font-weight: 700; color: white; font-family: 'Arial', sans-serif; letter-spacing: 1px;">
                    eHeat
                </h1>
                <span style="font-size: 20px; font-weight: 500; color: rgba(255,255,255,0.9);">Dashboard – Ergebnisse</span>
            </div>
            <p style="margin: 8px 0 0 0; font-size: 13px; color: rgba(255,255,255,0.85); font-weight: 400;">
                {len(self.available_workflows)} gespeicherte Simulationen | Institut für Energieeffizienz in der Produktion EEP
            </p>
        </div>
        <div style="text-align: right; margin-left: 30px;">
            <div style="font-size: 24px; font-weight: 700; letter-spacing: 2px; color: white;">
                UNIVERSITÄT
            </div>
            <div style="font-size: 24px; font-weight: 700; letter-spacing: 2px; color: white;">
                STUTTGART
            </div>
        </div>
    </div>
</div>
            """,
            sizing_mode='stretch_width'
        )

        # Helper function to create unique dropdown labels
        def create_workflow_options(workflows):
            """Create unique, informative dropdown labels for workflows."""
            options = {}
            for i, wf in enumerate(workflows):
                # Create unique, informative dropdown label
                name = wf['name']

                # Use directory name if generic name like "Scenario Studio Run"
                if name in ["Scenario Studio Run", "Baseline Simulation", "Workflow Run"]:
                    # Extract meaningful parts from directory name
                    dir_name = wf['path'].name
                    # Format: 20251202_050933_PF_FULL_YEAR-Baseline
                    # -> PF_FULL_YEAR-Baseline
                    if '_' in dir_name:
                        parts = dir_name.split('_', 2)  # Split max 2 times
                        if len(parts) >= 3:
                            name = parts[2]  # Get the descriptive part

                # Format date with time for uniqueness
                date_str = wf['date'][:16] if wf['date'] and len(wf['date']) >= 16 else 'no date'
                date_str = date_str.replace('T', ' ')  # 2025-12-02 05:09

                # Add workflow steps for clarity
                steps_str = ' → '.join(wf['steps']) if wf['steps'] else 'N/A'

                # Create unique label: "2025-12-02 05:09 | PF_FULL_YEAR-Baseline | PF"
                label = f"{date_str} | {name} | {steps_str}"
                options[label] = i

            return options

        # Workflow selector dropdown
        workflow_options = create_workflow_options(self.available_workflows)

        workflow_selector = pn.widgets.Select(
            name='Simulation auswählen',
            options=workflow_options,
            sizing_mode='stretch_width'  # Adapt to container width
        )

        # Refresh button
        refresh_button = pn.widgets.Button(
            name='Aktualisieren',
            button_type='success',
            width=150
        )

        # Status indicator for refresh
        refresh_status = pn.pane.Markdown("", width=200)

        # Refresh callback
        def on_refresh(event):
            """Rescan workflows and update dropdown."""
            refresh_status.object = "Aktualisiere..."

            # Rescan workflows
            self.available_workflows = self._scan_workflows()

            # Reset selector value first (important for Panel to recognize change)
            workflow_selector.value = None

            # Update dropdown options with unique labels
            new_options = create_workflow_options(self.available_workflows)
            workflow_selector.options = new_options

            # Force Panel to update the widget
            workflow_selector.param.trigger('options')

            # Update status
            refresh_status.object = f"{len(self.available_workflows)} Simulationen gefunden"

            logger.info(f"Refreshed: {len(self.available_workflows)} workflows found, {len(new_options)} options created")

            # Clear status after 3 seconds
            import threading
            import time
            def clear_status():
                time.sleep(3)
                refresh_status.object = ""
            threading.Thread(target=clear_status, daemon=True).start()

        refresh_button.on_click(on_refresh)

        # Info panel (reactive) - more compact styling
        @pn.depends(workflow_selector.param.value)
        def info_panel(selected_idx):
            if selected_idx is None:
                return pn.pane.Markdown(
                    "<div style='padding: 15px; background: #f8f9fa; border-radius: 6px; "
                    "border-left: 4px solid #0066cc;'>"
                    "<em>◂ Wähle eine Simulation aus dem Dropdown</em></div>"
                )

            wf = self.available_workflows[selected_idx]

            # Format date nicely
            date_display = wf['date'][:16].replace('T', ' ') if wf['date'] else 'Unbekannt'

            # Format costs
            costs_display = f"{wf['costs']:,.0f} €" if wf['costs'] else "Keine Daten"

            # Format steps
            steps_display = ' → '.join(wf['steps']) if wf['steps'] else 'N/A'

            info_md = f"""
<div style="padding: 15px; background: #f8f9fa; border-radius: 6px;
            border-left: 4px solid #28a745; line-height: 1.6;">
    <h4 style="margin: 0 0 12px 0; color: #28a745;">■ Simulation Details</h4>
    <table style="width: 100%; font-size: 13px;">
        <tr><td style="padding: 4px 0;"><strong>Gespeichert:</strong></td><td>{date_display}</td></tr>
        <tr><td style="padding: 4px 0;"><strong>Workflow:</strong></td><td>{steps_display}</td></tr>
        <tr><td style="padding: 4px 0;"><strong>Gesamtkosten:</strong></td><td>{costs_display}</td></tr>
        <tr><td style="padding: 4px 0;"><strong>Szenario:</strong></td><td>{wf['scenario']}</td></tr>
    </table>
</div>
"""
            return pn.pane.Markdown(info_md)

        # Dashboard tabs (reactive)
        @pn.depends(workflow_selector.param.value)
        def dashboard_tabs(selected_idx):
            if selected_idx is None:
                return pn.pane.Markdown("*Wähle eine Simulation aus, um das Dashboard anzuzeigen*")

            wf_info = self.available_workflows[selected_idx]

            # Load workflow
            workflow = self._load_workflow(wf_info)

            if workflow is None:
                return pn.pane.Markdown(
                    f"## FEHLER: Fehler beim Laden\n\n"
                    f"Workflow konnte nicht geladen werden: `{wf_info['path']}`"
                )

            # Create dashboard using existing dashboard module
            from calion.io.dashboard import create_dashboard

            try:
                dashboard = create_dashboard(workflow, title=wf_info['name'], diagnose=False)
                return dashboard
            except Exception as e:
                logger.error(f"Failed to create dashboard: {e}")
                import traceback
                return pn.pane.Markdown(
                    f"## FEHLER: Dashboard-Fehler\n\n"
                    f"```\n{traceback.format_exc()}\n```"
                )

        # Comparison button (shows when 2+ workflows available) - compact
        comparison_section = pn.Column()

        if len(self.available_workflows) >= 2:
            comparison_button = pn.widgets.Button(
                name='Vergleichs-Modus',
                button_type='primary',
                width=180,
                height=35
            )

            comparison_section.append(
                pn.Card(
                    comparison_button,
                    title="",
                    header_background="#f8f9fa",
                    hide_header=True,
                    margin=(10, 0),
                    styles={'padding': '8px'}
                )
            )

        # Compact, clean layout - fixed dropdown overlap
        layout = pn.Column(
            header,
            pn.Row(
                pn.Column(
                    # Control panel with card styling
                    pn.Card(
                        workflow_selector,
                        pn.Row(
                            refresh_button,
                            refresh_status,
                            styles={'padding': '8px 0', 'margin': '0'}
                        ),
                        title="",
                        hide_header=True,
                        styles={
                            'background': 'white',
                            'padding': '20px',
                            'box-shadow': '0 1px 3px rgba(0,0,0,0.1)'
                        },
                        margin=(0, 15, 15, 0)
                    ),
                    info_panel,
                    comparison_section,
                    width=450,  # Increased from 420 for better spacing
                    styles={'padding-right': '0'},
                    sizing_mode='fixed'
                ),
                pn.Column(
                    dashboard_tabs,
                    sizing_mode='stretch_width',
                    styles={
                        'padding-left': '20px',
                        'border-left': '2px solid #e0e0e0',
                        'min-width': '600px'
                    }
                )
            ),
            sizing_mode='stretch_width',
            margin=(0, 20)
        )

        return layout
